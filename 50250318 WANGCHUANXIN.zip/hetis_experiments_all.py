from __future__ import annotations

import argparse
import sys
from pathlib import Path

from rich.console import Console
from rich.table import Table


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from hetis_sim.evaluation.plots import plot_scheduler_comparison, plot_single_result
from hetis_sim.evaluation.result_writer import ResultWriter
from hetis_sim.models.cluster import Cluster
from hetis_sim.models.metrics import SimulationResult
from hetis_sim.schedulers import build_scheduler
from hetis_sim.simulation.engine import SimulationEngine
from hetis_sim.simulation.workload_generator import WorkloadGenerator, load_workload_config


console = Console()

CLUSTER_CONFIG = ROOT / "configs" / "cluster_a100_v100_t4.yaml"
WORKLOAD_SHAREGPT = ROOT / "configs" / "workload_sharegpt.yaml"
WORKLOAD_BURST = ROOT / "configs" / "workload_burst.yaml"
WORKLOAD_LONG_CONTEXT = ROOT / "configs" / "workload_long_context.yaml"


def run_experiment(
    *,
    experiment_name: str,
    cluster_path: Path,
    workload_path: Path,
    scheduler_name: str = "dynamic_hetis",
) -> tuple[SimulationResult, Path]:
    """Run one Hetis-Sim experiment and write JSON/CSV/HTML/PNG outputs."""
    cluster = Cluster.from_yaml(cluster_path)
    workload = load_workload_config(workload_path)
    requests = WorkloadGenerator(workload).generate()
    scheduler = build_scheduler(scheduler_name, cluster.model_profile)

    console.rule(f"{experiment_name} | {scheduler.name}")
    console.print(
        f"请求数: {len(requests)}，负载: {workload.get('name')}，结果类型: simulation"
    )

    result = SimulationEngine(
        cluster,
        scheduler,
        requests,
        workload.get("name", "synthetic"),
    ).run()

    output_dir = ResultWriter(ROOT / "results").write(
        result,
        experiment_name=experiment_name,
    )
    plot_single_result(result, output_dir)
    print_summary_table(result)
    console.print(f"[green]输出目录:[/green] {output_dir}")
    return result, output_dir


def compare_schedulers(
    *,
    experiment_name: str,
    cluster_path: Path,
    workload_path: Path,
    scheduler_names: list[str],
) -> tuple[list[SimulationResult], Path]:
    """Run the same workload with multiple schedulers and write comparison charts."""
    cluster = Cluster.from_yaml(cluster_path)
    workload = load_workload_config(workload_path)
    requests = WorkloadGenerator(workload).generate()
    results: list[SimulationResult] = []
    base_dir = ROOT / "results" / experiment_name

    for scheduler_name in scheduler_names:
        scheduler = build_scheduler(scheduler_name, cluster.model_profile)
        console.rule(f"{experiment_name} | {scheduler.name}")

        result = SimulationEngine(
            cluster,
            scheduler,
            requests,
            workload.get("name", "synthetic"),
        ).run()

        output_dir = ResultWriter(ROOT / "results").write(
            result,
            experiment_name=f"{experiment_name}_{scheduler.name}",
        )
        plot_single_result(result, output_dir)
        print_summary_table(result)
        results.append(result)

    comparison_dir = base_dir / "comparison"
    comparison_dir.mkdir(parents=True, exist_ok=True)
    plot_scheduler_comparison(results, comparison_dir)
    console.print(f"[green]对比输出目录:[/green] {comparison_dir}")
    return results, comparison_dir


def print_summary_table(result: SimulationResult) -> None:
    """Print key simulation metrics in a report-friendly table."""
    table = Table(title=f"{result.scheduler_name} 仿真摘要")
    table.add_column("指标")
    table.add_column("值", justify="right")

    for key in [
        "completed_requests",
        "failed_requests",
        "average_latency_s",
        "p95_latency_s",
        "p99_latency_s",
        "throughput_rps",
        "token_throughput_tps",
        "oom_count",
        "reschedule_count",
        "communication_overhead_ratio",
    ]:
        value = result.summary.get(key, "")
        if isinstance(value, float):
            value = f"{value:.4f}"
        table.add_row(key, str(value))

    console.print(table)


def experiment_1_sharegpt_like(scheduler_name: str = "dynamic_hetis") -> tuple[SimulationResult, Path]:
    return run_experiment(
        experiment_name="experiment_1_sharegpt_like",
        cluster_path=CLUSTER_CONFIG,
        workload_path=WORKLOAD_SHAREGPT,
        scheduler_name=scheduler_name,
    )


def experiment_2_burst_traffic(scheduler_name: str = "dynamic_hetis") -> tuple[SimulationResult, Path]:
    return run_experiment(
        experiment_name="experiment_2_burst_traffic",
        cluster_path=CLUSTER_CONFIG,
        workload_path=WORKLOAD_BURST,
        scheduler_name=scheduler_name,
    )


def experiment_3_long_context(scheduler_name: str = "dynamic_hetis") -> tuple[SimulationResult, Path]:
    return run_experiment(
        experiment_name="experiment_3_long_context",
        cluster_path=CLUSTER_CONFIG,
        workload_path=WORKLOAD_LONG_CONTEXT,
        scheduler_name=scheduler_name,
    )


def experiment_4_scheduler_comparison() -> tuple[list[SimulationResult], Path]:
    return compare_schedulers(
        experiment_name="experiment_4_scheduler_comparison",
        cluster_path=CLUSTER_CONFIG,
        workload_path=WORKLOAD_SHAREGPT,
        scheduler_names=["homogeneous", "static_hexgen", "dynamic_hetis"],
    )


def run_all(scheduler_name: str = "dynamic_hetis") -> None:
    experiment_1_sharegpt_like(scheduler_name)
    experiment_2_burst_traffic(scheduler_name)
    experiment_3_long_context(scheduler_name)
    experiment_4_scheduler_comparison()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Hetis-Sim all-in-one experimental runner",
    )
    parser.add_argument(
        "--experiment",
        default="all",
        choices=["sharegpt", "burst", "long_context", "comparison", "all"],
        help="选择要运行的实验",
    )
    parser.add_argument(
        "--scheduler",
        default="dynamic_hetis",
        choices=[
            "homogeneous",
            "homogeneous_baseline",
            "static_hexgen",
            "static_hexgen_like",
            "dynamic_hetis",
            "hetis",
        ],
        help="单实验使用的调度器；comparison 固定对比三种调度器",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.experiment == "sharegpt":
        experiment_1_sharegpt_like(args.scheduler)
    elif args.experiment == "burst":
        experiment_2_burst_traffic(args.scheduler)
    elif args.experiment == "long_context":
        experiment_3_long_context(args.scheduler)
    elif args.experiment == "comparison":
        experiment_4_scheduler_comparison()
    else:
        run_all(args.scheduler)


if __name__ == "__main__":
    main()
